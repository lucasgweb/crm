<?php
use core\Router;

$router = new Router();

$router->get('/login', 'LoginController@index');
$router->post('/login', 'LoginController@auth');
$router->get('/logout/{id}', 'LoginController@logout');

$router->get('/','HomeController@index');

$router->get('/usuarios', 'UserController@index');
$router->get('/usuario/{id}', 'UserController@delete');
$router->get('/profile', 'UserController@editProfile');
$router->post('/profile', 'UserController@editProfileAction');

$router->post('/usuarios', 'UserController@store');
$router->post('/usuarios/edit', 'UserController@edit');

$router->get('/leads', 'LeadController@index');
$router->post('/leads', 'LeadController@store');
$router->get('/leads/delete/{id}', 'LeadController@delete');
$router->post('/lead-update', 'LeadController@update');
$router->get('/importarleads', 'LeadController@import');


$router->get('/misleads', 'MisLeadsController@index');
$router->post('/mi-lead-update', 'MisLeadsController@update');

$router->get('/reporteleads', 'ReportesController@reporteLeads');
$router->get('/reporteleadsvendedor', 'ReportesController@reporteLeadsVendedor');

$router->get('/chat', 'ChatController@index');
$router->get('/chat/{id}', 'ChatController@chat');

$router->post('/chat', 'ChatController@store');

$router->get('/alumnos', 'AlumnoController@index');

$router->get('/profesores', 'ProfesorController@index');

$router->get('/categorias', 'CategoriaController@index');

$router->get('/tipos', 'TipoController@index');

$router->get('/modalidades', 'ModalidadController@index');

$router->get('/cursos', 'CursoController@index');
