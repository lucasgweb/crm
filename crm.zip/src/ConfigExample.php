<?php
namespace src;

class Config {
    const BASE_DIR = '/crm-mvc/public';

    const DB_DRIVER = 'mysql';
    const DB_HOST = 'localhost';
    const DB_DATABASE = 'crm';
    CONST DB_USER = 'root';
    const DB_PASS = '';

    const ERROR_CONTROLLER = 'ErrorController';
    const DEFAULT_ACTION = 'index';
}


<?php
namespace src;

class Config {
    const BASE_DIR = '';

    const DB_DRIVER = 'mysql';
    const DB_HOST = 'localhost';
    const DB_DATABASE = 'lcgtic00_lcgti';
    CONST DB_USER = 'lcgtic00_lucas';
    const DB_PASS = 'lu159357';

    const ERROR_CONTROLLER = 'ErrorController';
    const DEFAULT_ACTION = 'index';
}